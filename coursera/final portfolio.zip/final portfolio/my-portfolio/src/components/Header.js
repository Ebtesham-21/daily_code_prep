import React from 'react';
import { Link } from 'react-scroll'; 

const Header = () => {
    return (
        <header>
            <nav>
                <Link to="landing" smooth={true} duration = {500}>
                    Home
                </Link>
                <Link to="landing" smooth={true} duration = {500}>
                    Projects
                </Link>
                <Link to="landing" smooth={true} duration = {500}>
                    Conatact
                </Link>
                {/* social media add hovye */}
              
            </nav>
        </header>
    );
};

export default Header;